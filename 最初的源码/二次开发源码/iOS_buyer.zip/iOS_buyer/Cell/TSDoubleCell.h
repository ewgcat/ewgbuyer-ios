//
//  TSDoubleCell.h
//  My_App
//
//  Created by barney on 16/3/31.
//  Copyright © 2016年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TSDoubleCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *img;
@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet UIButton *TSBtn;

@end
