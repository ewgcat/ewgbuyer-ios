//
//  goodsTie_evaluationCell.h
//  My_App
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface goodsTie_evaluationCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *publicBtn;
@property (weak, nonatomic) IBOutlet UITextView *contentTextView;

@end
