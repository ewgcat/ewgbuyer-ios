//
//  TSDoubleCell.m
//  My_App
//
//  Created by barney on 16/3/31.
//  Copyright © 2016年 barney. All rights reserved.
//

#import "TSDoubleCell.h"

@implementation TSDoubleCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
