//
//  WaitForEvaluateCell.h
//  My_App
//
//  Created by shiyuwudi on 15/11/30.
//  Copyright © 2015年 shiyuwudi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WaitForEvaluateCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *status;
@property (weak, nonatomic) IBOutlet UILabel *orderNum;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UIButton *button;
@property (weak, nonatomic) IBOutlet UIView *line;
@property (copy, nonatomic) NSString *order_id;
@property (assign, nonatomic)NSInteger goods_id;

@end
