//
//  GoodListColCell.m
//  My_App
//
//  Created by apple on 15-1-9.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "GoodListColCell.h"

@implementation GoodListColCell

- (void)awakeFromNib {
    // Initialization code
}

@end
