//
//  GroupPurchaseCell4.h
//  My_App
//
//  Created by barney on 15/12/8.
//  Copyright © 2015年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupPurcheaseDetailModel.h"


@interface GroupPurchaseCell4 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *mainTitle;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *distance;
@property (weak, nonatomic) IBOutlet UIButton *phone;
@property (nonatomic,strong)GroupPurcheaseDetailModel *model;
@property (weak, nonatomic) IBOutlet UIImageView *locationView;

+(instancetype)cell4WithTableView:(UITableView *)tableView;
@end
