//
//  PositionsCell.h
//  My_App
//
//  Created by apple on 15/8/27.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PositionsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@end
