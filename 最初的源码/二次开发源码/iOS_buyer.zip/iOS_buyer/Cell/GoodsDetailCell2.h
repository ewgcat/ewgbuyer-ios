//
//  GoodsDetailCell2.h
//  My_App
//
//  Created by apple on 15/12/10.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodsDetailCell2 : UITableViewCell

@property(nonatomic,strong)UILabel *totalQuantityLabel;
@property(nonatomic,strong)UILabel *availableQuantitiesLabel;

@end
