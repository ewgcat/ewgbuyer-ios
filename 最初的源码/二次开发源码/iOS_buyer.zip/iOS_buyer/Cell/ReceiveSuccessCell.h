//
//  ReceiveSuccessCell.h
//  My_App
//
//  Created by apple on 15/10/14.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReceiveSuccessCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *UseBtn;

@end
