//
//  GoodsDetailCell7.h
//  My_App
//
//  Created by apple on 15/12/11.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodsDetailCell7 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lineLabel;

@property(nonatomic,strong)UIButton *liftbutton;
@property(nonatomic,strong)UIButton *rightbutton;

@property(nonatomic,strong)NSString *liftStr;
@property(nonatomic,strong)NSString *rightStr;

@end
