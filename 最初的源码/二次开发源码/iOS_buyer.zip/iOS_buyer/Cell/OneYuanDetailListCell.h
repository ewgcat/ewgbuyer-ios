//
//  OneYuanDetailListCell.h
//  My_App
//
//  Created by barney on 16/2/17.
//  Copyright © 2016年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneYuanDetailListCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *img;
@property (weak, nonatomic) IBOutlet UILabel *userName;
@property (weak, nonatomic) IBOutlet UILabel *content;

@end
