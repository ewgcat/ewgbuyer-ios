//
//  floorTitleCell.h
//  My_App
//
//  Created by apple on 15/7/15.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface floorTitleCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *floorLabel;

@end
