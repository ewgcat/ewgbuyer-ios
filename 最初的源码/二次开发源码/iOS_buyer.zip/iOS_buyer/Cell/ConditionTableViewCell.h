//
//  ConditionTableViewCell.h
//  
//
//  Created by apple on 15/10/21.
//
//

#import <UIKit/UIKit.h>
#import "AreaModel.h"

@interface ConditionTableViewCell : UITableViewCell
@property(nonatomic,strong)AreaModel *model;

@end
