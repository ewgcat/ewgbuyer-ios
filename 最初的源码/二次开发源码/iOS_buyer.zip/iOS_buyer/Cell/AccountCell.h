//
//  AccountCell.h
//  
//
//  Created by apple on 15/10/14.
//
//

#import <UIKit/UIKit.h>
#import "AccountModel.h"

@interface AccountCell : UITableViewCell

@property(nonatomic,strong)AccountModel *model;

@end
