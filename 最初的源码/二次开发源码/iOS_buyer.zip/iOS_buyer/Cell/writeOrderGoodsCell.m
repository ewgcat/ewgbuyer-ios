//
//  writeOrderGoodsCell.m
//  My_App
//
//  Created by barney on 16/4/11.
//  Copyright © 2016年 barney. All rights reserved.
//

#import "writeOrderGoodsCell.h"

@implementation writeOrderGoodsCell

- (void)awakeFromNib {
    // Initialization code
    self.h1.constant=0.5;
    self.h2.constant=0.5;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
