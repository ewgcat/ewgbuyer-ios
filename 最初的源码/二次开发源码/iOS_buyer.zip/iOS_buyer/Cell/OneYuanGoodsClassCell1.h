//
//  OneYuanGoodsClassCell1.h
//  My_App
//
//  Created by barney on 16/2/16.
//  Copyright © 2016年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneYuanGoodsClassCell1 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIProgressView *progressView;
@property (weak, nonatomic) IBOutlet UILabel *goodsPrice;
@property (weak, nonatomic) IBOutlet UILabel *unAll;

@end
