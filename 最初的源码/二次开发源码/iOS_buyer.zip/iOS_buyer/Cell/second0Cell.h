//
//  second0Cell.h
//  My_App
//
//  Created by apple on 15/6/24.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface second0Cell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *name;

@end
