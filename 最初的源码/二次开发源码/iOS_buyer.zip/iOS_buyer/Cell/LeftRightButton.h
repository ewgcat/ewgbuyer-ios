//
//  LeftRightButton.h
//  SellerApp
//
//  Created by barney on 16/1/5.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE
@interface LeftRightButton : UIButton

+(instancetype)leftRightButtonWithImageName:(NSString *)imgName title:(NSString *)title frame:(CGRect)frame;

@end
