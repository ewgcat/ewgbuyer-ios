//
//  FGTableViewCell.h
//  My_App
//
//  Created by apple on 15/10/30.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "DNSSwipeableCell.h"
#import "Model.h"

@interface FGTableViewCell : DNSSwipeableCell

@property(nonatomic,strong)Model *model;

@end
