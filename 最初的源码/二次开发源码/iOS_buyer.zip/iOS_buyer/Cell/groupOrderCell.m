//
//  groupOrderCell.m
//  My_App
//
//  Created by apple on 15/6/17.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "groupOrderCell.h"

@implementation groupOrderCell

- (void)awakeFromNib {
    // Initialization code
    [_btn1.layer setMasksToBounds:YES];
    [_btn1.layer setCornerRadius:4];
    [_btn2.layer setMasksToBounds:YES];
    [_btn2.layer setCornerRadius:4];
    _btn1.layer.borderColor =UIColorFromRGB(0xdb232c).CGColor;
    _btn1.layer.borderWidth = 0.5;
    _btn2.layer.borderColor = UIColorFromRGB(0xdb232c).CGColor;
    _btn2.layer.borderWidth = 0.5;
    
    
    [_checkLabel.layer setMasksToBounds:YES];
    [_checkLabel.layer setCornerRadius:4];
    _checkLabel.layer.borderColor = [MY_COLOR CGColor];
    _checkLabel.layer.borderWidth = 0.5;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
