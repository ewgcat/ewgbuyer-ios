//
//  GroupPurchaseCell3.h
//  My_App
//
//  Created by barney on 15/12/8.
//  Copyright © 2015年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupPurcheaseDetailModel.h"

@interface GroupPurchaseCell3 : UITableViewCell
@property (nonatomic,strong)GroupPurcheaseDetailModel *model;

+(instancetype)cell3WithTableView:(UITableView *)tableView;
@end
