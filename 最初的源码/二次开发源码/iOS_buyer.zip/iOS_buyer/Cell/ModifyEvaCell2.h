//
//  ModifyEvaCell2.h
//  My_App
//
//  Created by apple2 on 16/2/2.
//  Copyright © 2016年 apple2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModifyEvaCell2 : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UILabel *label2;
@property (weak, nonatomic) IBOutlet UILabel *label3;
@property (weak, nonatomic) IBOutlet UIView *starHolder;


@end
