//
//  UsercenterCell.h
//  My_App
//
//  Created by apple on 15/6/11.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UsercenterCell : UITableViewCell{
//    __weak IBOutlet UIImageView *circleImage;
}
//top
@property (weak, nonatomic) IBOutlet UILabel *levelLabel;
@property (weak, nonatomic) IBOutlet UILabel *MessageCount;
@property (weak, nonatomic) IBOutlet UIButton *attentionGoodsBtn;
@property (weak, nonatomic) IBOutlet UIButton *attentionTrace;
@property (weak, nonatomic) IBOutlet UIButton *attentionStore;
@property (weak, nonatomic) IBOutlet UILabel *attentionStoreCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *attentionStoreLabel;
@property (weak, nonatomic) IBOutlet UILabel *attentionGoodsCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *attentionGoodsLabel;
@property (weak, nonatomic) IBOutlet UILabel *attentionTraceCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *attentionTraceLabel;

@property (weak, nonatomic) IBOutlet UIImageView *photoImage;
@property (weak, nonatomic) IBOutlet UIImageView *circleImage;
@property (weak, nonatomic) IBOutlet UIButton *rechargeCard;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@property (weak, nonatomic) IBOutlet UIButton *ManagerOrder;

//订单按钮
@property (weak, nonatomic) IBOutlet UIButton *will_payOrderBtn;
@property (weak, nonatomic) IBOutlet UIButton *will_goodsOrderBtn;
@property (weak, nonatomic) IBOutlet UIButton *will_evolateOrderBtn;
@property (weak, nonatomic) IBOutlet UIButton *will_returnOrderBtn;
@property (weak, nonatomic) IBOutlet UIButton *waitGoodsBtn;
@property (weak, nonatomic) IBOutlet UIButton *userInformation;
@property (weak, nonatomic) IBOutlet UIButton *btn_setting;
@property (weak, nonatomic) IBOutlet UIButton *btn_message;

// 2015 11 19 修改
@property (weak, nonatomic) IBOutlet UIButton *mBalanceBtn;
@property (weak, nonatomic) IBOutlet UIButton *mIntegralBtn;
@property (weak, nonatomic) IBOutlet UIButton *mCouponBtn;
@property (weak, nonatomic) IBOutlet UIButton *mPrepaidCardBtn;
@property (weak, nonatomic) IBOutlet UIButton *mLifeCheepBtn;

@property (weak, nonatomic) IBOutlet UIButton *mAddressBtn;
@property (weak, nonatomic) IBOutlet UIButton *mAccountSafetyBtn;
@property (weak, nonatomic) IBOutlet UIButton *mServiceBtn;


// 2016 1 13 修改 00025
@property (weak, nonatomic) IBOutlet UILabel *managementLabel;
@property (weak, nonatomic) IBOutlet UIImageView *disImage;
//2016 1 22 修改 00025
@property (weak, nonatomic) IBOutlet UIImageView *notLoggedcircleImage;
@property (weak, nonatomic) IBOutlet UIImageView *notLoggedphotoImage;

@end
