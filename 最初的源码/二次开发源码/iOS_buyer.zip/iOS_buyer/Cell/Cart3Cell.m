//
//  Cart3Cell.m
//  My_App
//
//  Created by apple on 15/12/9.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "Cart3Cell.h"

@implementation Cart3Cell

- (void)awakeFromNib {
    // Initialization code
    _pictureImageView.layer.borderWidth = 0.5;
//    _pictureImageView.layer.borderColor = [[UIColor lightGrayColor] CGColor];
  _pictureImageView.layer.borderColor = [UIColorFromRGB(0xd7d7d7) CGColor];
     _markImageView.hidden=YES;
    _markbgImageView.hidden=YES;

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
