//
//  WritePayCell.m
//  My_App
//
//  Created by shiyuwudi on 15/12/10.
//  Copyright © 2015年 shiyuwudi. All rights reserved.
//

#import "WritePayCell.h"

@implementation WritePayCell

- (void)awakeFromNib {
    // Initialization code
    self.h1.constant=0.5;
    self.h2.constant=0.5;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
