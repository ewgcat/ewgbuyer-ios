//
//  zeroDetailCell.h
//  My_App
//
//  Created by apple on 15/6/23.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface zeroDetailCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *publicCount;
@property (weak, nonatomic) IBOutlet UILabel *remainCount;
@property (weak, nonatomic) IBOutlet UILabel *applyCount;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UIButton *eveloateBtn;
@property (weak, nonatomic) IBOutlet UIImageView *photoImage;

@end
