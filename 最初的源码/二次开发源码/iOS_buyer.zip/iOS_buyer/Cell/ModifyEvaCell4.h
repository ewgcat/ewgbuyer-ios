//
//  ModifyEvaCell4.h
//  My_App
//
//  Created by apple2 on 16/2/2.
//  Copyright © 2016年 apple2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModifyEvaCell4 : UITableViewCell

@end
