//
//  StandingsCell.h
//  
//
//  Created by apple on 15/10/16.
//
//

#import <UIKit/UIKit.h>
#import "AccountModel.h"
@interface StandingsCell : UITableViewCell

@property(nonatomic,strong)AccountModel *model;

@end
