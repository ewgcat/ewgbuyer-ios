//
//  ModifyEvaCell1.h
//  My_App
//
//  Created by apple2 on 16/2/2.
//  Copyright © 2016年 apple2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModifyEvaCell1 : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageView1;
@property (weak, nonatomic) IBOutlet UILabel *goodsName;

@end
