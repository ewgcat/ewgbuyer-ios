//
//  SimilarTableViewCell.h
//  
//
//  Created by apple on 15/10/20.
//
//

#import <UIKit/UIKit.h>
#import "Model.h"

@interface SimilarTableViewCell : UITableViewCell

@property(nonatomic,strong)Model *model;

@end
