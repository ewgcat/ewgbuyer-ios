//
//  recordCell.h
//  My_App
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface recordCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *rechargeStatus;
@property (weak, nonatomic) IBOutlet UIButton *rechargeBtn;

@end
