//
//  ModifyEvaCell3.m
//  My_App
//
//  Created by apple2 on 16/2/2.
//  Copyright © 2016年 apple2. All rights reserved.
//

#import "ModifyEvaCell3.h"

@implementation ModifyEvaCell3

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
