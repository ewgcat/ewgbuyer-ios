//
//  GoodsDetailCell3.h
//  My_App
//
//  Created by apple on 15/12/10.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodsDetailCell3 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *specificationsLabel;

@end
