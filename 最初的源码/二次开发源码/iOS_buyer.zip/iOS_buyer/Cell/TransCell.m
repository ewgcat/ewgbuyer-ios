//
//  TransCell.m
//  My_App
//
//  Created by barney on 15/12/3.
//  Copyright © 2015年 barney. All rights reserved.
//

#import "TransCell.h"

@implementation TransCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
