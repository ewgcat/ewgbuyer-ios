//
//  GoodsListViewController.h
//  My_App
//
//  Created by apple on 15-2-5.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"
@interface GoodsListViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    NSMutableArray *billdataArray;
    ASIFormDataRequest *request102;
    

    __weak IBOutlet UILabel *labelTi;
    __weak IBOutlet UIView *nothingView;
    __weak IBOutlet UITableView *MyTableView;

}

@end
