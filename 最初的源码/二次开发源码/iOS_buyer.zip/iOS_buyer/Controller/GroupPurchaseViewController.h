//
//  GroupPurchaseViewController.h
//  
//
//  Created by apple on 15/10/21.
//
//

#import <UIKit/UIKit.h>

@interface GroupPurchaseViewController : UIViewController

@end
