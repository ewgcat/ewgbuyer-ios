//
//  MyCollectViewController.h
//  
//
//  Created by apple on 15/10/19.
//
//

#import <UIKit/UIKit.h>

@interface MyCollectViewController : UIViewController

@property(nonatomic,strong)NSString * flay;

@end
