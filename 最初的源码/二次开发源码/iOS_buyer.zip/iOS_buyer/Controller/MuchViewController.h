//
//  MuchViewController.h
//  My_App
//
//  Created by apple on 14-7-31.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MuchViewController : UIViewController<UIAlertViewDelegate>

@property (weak, nonatomic) IBOutlet UIButton *logoutBtn;

- (IBAction)contactUsBtnClicked:(id)sender;
- (IBAction)usehelpBtnClicked:(id)sender;
- (IBAction)clearBtnClicked:(id)sender;
- (IBAction)aboutBtnClicked:(id)sender;
- (IBAction)agreeBtcClicked:(id)sender;
- (IBAction)feedBackBtnClicked:(id)sender;

@end
