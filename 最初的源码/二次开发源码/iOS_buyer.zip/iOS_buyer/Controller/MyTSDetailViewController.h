//
//  MyTSDetailViewController.h
//  My_App
//
//  Created by barney on 15/12/1.
//  Copyright © 2015年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTSDetailViewController : UIViewController
@property(nonatomic,copy)NSString *TSID;
@end
