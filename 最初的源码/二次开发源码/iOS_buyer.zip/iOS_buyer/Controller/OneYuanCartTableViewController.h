//
//  OneYuanCartTableViewController.h
//  My_App
//
//  Created by shiyuwudi on 16/2/16.
//  Copyright © 2016年 shiyuwudi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTableViewControllerNoTabBarWithEmptySet.h"

@interface OneYuanCartTableViewController : BaseTableViewControllerNoTabBarWithEmptySet

@end
