//
//  CombinedViewController.h
//  My_App
//
//  Created by apple on 15/12/16.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClassifyModel.h"

@interface CombinedViewController : UIViewController

@property(nonatomic,strong)ClassifyModel *model;
@property(nonatomic,strong)NSString *goodsCount;

@end
