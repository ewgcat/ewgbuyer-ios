//
//  GroupMapViewController.h
//  My_App
//
//  Created by barney on 15/12/11.
//  Copyright © 2015年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupPurcheaseDetailModel.h"
@interface GroupMapViewController : UIViewController
@property(nonatomic,strong)GroupPurcheaseDetailModel *mapModel;

@end
