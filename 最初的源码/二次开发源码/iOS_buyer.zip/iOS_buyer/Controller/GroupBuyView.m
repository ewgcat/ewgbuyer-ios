//
//  GroupBuyView.m
//  My_App
//
//  Created by barney on 15/12/10.
//  Copyright © 2015年 barney. All rights reserved.
//

#import "GroupBuyView.h"

@implementation GroupBuyView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/



@end
