//
//  OneYuanGoodsClassCell0.m
//  My_App
//
//  Created by barney on 16/2/23.
//  Copyright © 2016年 barney. All rights reserved.
//

#import "OneYuanGoodsClassCell0.h"

@implementation OneYuanGoodsClassCell0

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
