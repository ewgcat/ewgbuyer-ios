//
//  OneYuanGoodsLoginCell.h
//  My_App
//
//  Created by barney on 16/2/16.
//  Copyright © 2016年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneYuanGoodsLoginCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UILabel *lab;
@property (weak, nonatomic) IBOutlet UIView *grayView;

@end
