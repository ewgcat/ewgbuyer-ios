//
//  getActivityGoodsCollectionReusableView.m
//  My_App
//
//  Created by apple on 15/10/27.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "getActivityGoodsCollectionReusableView.h"

@implementation getActivityGoodsCollectionReusableView

- (void)awakeFromNib {
    // Initialization code
}

@end
