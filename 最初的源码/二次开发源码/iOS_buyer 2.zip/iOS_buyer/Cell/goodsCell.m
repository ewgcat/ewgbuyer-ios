//
//  goodsCell.m
//  My_App
//
//  Created by apple on 15/6/16.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "goodsCell.h"

@implementation goodsCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
