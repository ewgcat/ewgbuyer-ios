//
//  FavoriteStopsTableViewCell.h
//  
//
//  Created by apple on 15/10/19.
//
//

#import <UIKit/UIKit.h>
#import "Model.h"
@interface FavoriteStopsTableViewCell : UITableViewCell

@property(nonatomic,strong)Model *model;

@end
