//
//  ModifyEvaCell1.m
//  My_App
//
//  Created by apple2 on 16/2/2.
//  Copyright © 2016年 apple2. All rights reserved.
//

#import "ModifyEvaCell1.h"

@implementation ModifyEvaCell1

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
