//
//  spendingBalanceCell.m
//  My_App
//
//  Created by apple on 15/8/6.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "spendingBalanceCell.h"

@implementation spendingBalanceCell

- (void)awakeFromNib {
    // Initialization code
    _desLabel = [[UILabel alloc]initWithFrame:CGRectMake(15, 55, ScreenFrame.size.width-30, 100)];
    _desLabel.text = @"地方哈斯法哈德法律上飞机阿萨德客服";
    _desLabel.numberOfLines = 0;
    [self addSubview:_desLabel];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
