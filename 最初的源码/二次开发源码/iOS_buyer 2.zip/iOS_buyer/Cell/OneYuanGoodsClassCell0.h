//
//  OneYuanGoodsClassCell0.h
//  My_App
//
//  Created by barney on 16/2/23.
//  Copyright © 2016年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneYuanGoodsClassCell0 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *allPrice;
@property (weak, nonatomic) IBOutlet UIButton *buyBtn;
@property (weak, nonatomic) IBOutlet UIButton *didNull;

@end
