//
//  SYOrderDetailsCell2.h
//  My_App
//
//  Created by shiyuwudi on 15/12/4.
//  Copyright © 2015年 shiyuwudi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYOrderDetailsCell2 : UITableViewCell

+(instancetype)cell2WithTableView:(UITableView *)tableView;

@end
