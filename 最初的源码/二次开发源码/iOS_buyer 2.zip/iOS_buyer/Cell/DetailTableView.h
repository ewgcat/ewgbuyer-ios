//
//  DetailTableView.h
//  My_App
//
//  Created by shiyuwudi on 16/3/11.
//  Copyright © 2016年 shiyuwudi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableView : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *publicCount;
@property (weak, nonatomic) IBOutlet UILabel *remainCount;
@property (weak, nonatomic) IBOutlet UILabel *applyCount;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UIButton *eveloateBtn;
@property (weak, nonatomic) IBOutlet UIImageView *photoImage;

@end
