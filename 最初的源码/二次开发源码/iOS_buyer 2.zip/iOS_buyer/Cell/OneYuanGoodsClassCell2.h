//
//  OneYuanGoodsClassCell2.h
//  My_App
//
//  Created by barney on 16/2/17.
//  Copyright © 2016年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneYuanGoodsClassCell2 : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (weak, nonatomic) IBOutlet UIButton *checkJS;
@property (weak, nonatomic) IBOutlet UILabel *winner;
@property (weak, nonatomic) IBOutlet UILabel *attend;
@property (weak, nonatomic) IBOutlet UILabel *resultTime;
@property (weak, nonatomic) IBOutlet UILabel *luckyNum;
@property (weak, nonatomic) IBOutlet UIImageView *avatar;



@end
