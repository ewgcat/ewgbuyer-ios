//
//  myEvaluation_tieCell.h
//  My_App
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface myEvaluation_tieCell : UITableViewCell
@property (strong,nonatomic)UILabel *labelContent ;
@property (weak, nonatomic) IBOutlet UIButton *tieBtn;
@end
