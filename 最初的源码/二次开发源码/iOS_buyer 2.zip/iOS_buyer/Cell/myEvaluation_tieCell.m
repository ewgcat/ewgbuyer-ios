//
//  myEvaluation_tieCell.m
//  My_App
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "myEvaluation_tieCell.h"

@implementation myEvaluation_tieCell

- (void)awakeFromNib {
    // Initialization code
    _labelContent = [[UILabel alloc]initWithFrame:CGRectMake(15, 96, ScreenFrame.size.width-30, 40)];
    _labelContent.text = @"评论内容评论内容评论内容评论内容评论内容评论内容评论内容评论内容评论内容评论内容评论内容评论内容评论内容";
    _labelContent.numberOfLines = 0;
    _labelContent.font = [UIFont systemFontOfSize:15];
    [self addSubview:_labelContent];
    [_tieBtn.layer setMasksToBounds:YES];
    [_tieBtn.layer setCornerRadius:4];
    _tieBtn.layer.borderColor = [[UIColor redColor] CGColor];
    _tieBtn.layer.borderWidth = 0.5;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
