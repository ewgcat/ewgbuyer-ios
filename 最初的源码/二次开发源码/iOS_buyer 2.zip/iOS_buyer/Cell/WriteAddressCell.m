//
//  WriteAddressCell.m
//  My_App
//
//  Created by shiyuwudi on 15/12/10.
//  Copyright © 2015年 shiyuwudi. All rights reserved.
//

#import "WriteAddressCell.h"

@implementation WriteAddressCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
