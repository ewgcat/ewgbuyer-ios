//
//  OneYuanGoodsClassCell3.h
//  My_App
//
//  Created by barney on 16/2/18.
//  Copyright © 2016年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneYuanGoodsClassCell3 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *num;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UIButton *JSBtn;
@property (weak, nonatomic) IBOutlet UILabel *minuteLab;
@property (weak, nonatomic) IBOutlet UILabel *secondLab;
@property (weak, nonatomic) IBOutlet UILabel *hundredSecond;
@property (weak, nonatomic) IBOutlet UIView *redView;

@end
