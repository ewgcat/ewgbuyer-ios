//
//  normalGoodsEvaluationCell.h
//  My_App
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface normalGoodsEvaluationCell : UITableViewCell
@property (strong,nonatomic)UILabel *labelContent;
@property (strong,nonatomic)UILabel *labelspec;
@property (weak, nonatomic) IBOutlet UILabel *userName;
@property (weak, nonatomic) IBOutlet UILabel *addTime;

@end
