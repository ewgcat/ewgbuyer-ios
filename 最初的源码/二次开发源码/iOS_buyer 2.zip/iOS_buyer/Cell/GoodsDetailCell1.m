//
//  GoodsDetailCell1.m
//  My_App
//
//  Created by apple on 15/12/10.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "GoodsDetailCell1.h"

@implementation GoodsDetailCell1

- (void)awakeFromNib {
    // Initialization code
    [_activityNameLabel.layer setMasksToBounds:YES];
    [_activityNameLabel.layer setCornerRadius:4.0];
    _activityNameLabel.layer.borderWidth = 0.5;
    _activityNameLabel.layer.borderColor = [UIColorFromRGB(0Xef0000) CGColor];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
