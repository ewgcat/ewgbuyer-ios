//
//  TopicCell.h
//  My_App
//
//  Created by barney on 15/11/26.
//  Copyright © 2015年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopicCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@property (weak, nonatomic) IBOutlet UILabel *contentLab;

@end
