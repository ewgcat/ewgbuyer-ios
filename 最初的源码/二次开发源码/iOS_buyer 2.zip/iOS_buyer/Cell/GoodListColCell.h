//
//  GoodListColCell.h
//  My_App
//
//  Created by apple on 15-1-9.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodListColCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgBG;
@property (weak, nonatomic) IBOutlet UIImageView *imgLog;
@property (weak, nonatomic) IBOutlet UILabel *lblYuanjia;
@property (weak, nonatomic) IBOutlet UILabel *lblXianjia;
@property (weak, nonatomic) IBOutlet UILabel *lblYishouchu;


@end
