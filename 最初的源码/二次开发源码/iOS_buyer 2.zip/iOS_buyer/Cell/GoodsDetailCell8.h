//
//  GoodsDetailCell8.h
//  My_App
//
//  Created by apple on 15/12/11.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodsDetailCell8 : UITableViewCell

@property(nonatomic,strong)NSDictionary *storeInfoDictionary;


@end
