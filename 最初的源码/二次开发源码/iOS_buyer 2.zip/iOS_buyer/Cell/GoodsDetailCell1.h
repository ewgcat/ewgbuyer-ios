//
//  GoodsDetailCell1.h
//  My_App
//
//  Created by apple on 15/12/10.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodsDetailCell1 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *activityNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *activityNameInfo;
@property (weak, nonatomic) IBOutlet UIImageView *arrow;


@end
