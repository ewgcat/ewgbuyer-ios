//
//  index_ad_Cell.h
//  My_App
//
//  Created by apple on 15/7/15.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface index_ad_Cell : UITableViewCell
//@property (weak, nonatomic) IBOutlet UIScrollView *myScrollView;
//@property (weak, nonatomic) IBOutlet UIImageView *one_imageV;
//@property (weak, nonatomic) IBOutlet UIImageView *two_imageV;
//@property (weak, nonatomic) IBOutlet UIImageView *three_imageV;
//@property (weak, nonatomic) IBOutlet UIImageView *four_imageV;
//@property (weak, nonatomic) IBOutlet UIImageView *five_imageV;
//@property (weak, nonatomic) IBOutlet UIImageView *six_imageV;
//@property (weak, nonatomic) IBOutlet UIImageView *seven_imageV;
//@property (weak, nonatomic) IBOutlet UIImageView *eite_imageV;
//@property (weak, nonatomic) IBOutlet UIButton *oneBtn;
//@property (weak, nonatomic) IBOutlet UIButton *twoBtn;
//@property (weak, nonatomic) IBOutlet UIButton *threeBtn;
//@property (weak, nonatomic) IBOutlet UIButton *fourBtn;
//@property (weak, nonatomic) IBOutlet UIButton *fiveBtn;
//@property (weak, nonatomic) IBOutlet UIButton *sixBtn;
//@property (weak, nonatomic) IBOutlet UIButton *sevenBtn;
//
//@property (weak, nonatomic) IBOutlet UIButton *eiteBtn;
//@property (weak, nonatomic) IBOutlet UIView *bottomView;






@end
