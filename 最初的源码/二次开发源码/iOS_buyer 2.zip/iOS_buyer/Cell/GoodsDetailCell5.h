//
//  GoodsDetailCell5.h
//  My_App
//
//  Created by apple on 15/12/11.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodsDetailCell5 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *highPraiseLabel;
@property (weak, nonatomic) IBOutlet UILabel *highLabel;

@end
