//
//  goodsTie_evaluationCell.m
//  My_App
//
//  Created by apple on 15/8/11.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "goodsTie_evaluationCell.h"

@implementation goodsTie_evaluationCell

- (void)awakeFromNib {
    // Initialization code
    [_publicBtn.layer setMasksToBounds:YES];
    [_publicBtn.layer setCornerRadius:4];
    _publicBtn.layer.borderColor = [[UIColor redColor] CGColor];
    _publicBtn.layer.borderWidth = 0.5;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
