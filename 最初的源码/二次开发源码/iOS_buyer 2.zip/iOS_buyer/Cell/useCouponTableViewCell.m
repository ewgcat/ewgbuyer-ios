//
//  useCouponTableViewCell.m
//  My_App
//
//  Created by apple on 14-8-26.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "useCouponTableViewCell.h"

@implementation useCouponTableViewCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
