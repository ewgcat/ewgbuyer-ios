//
//  GroupPurchaseCell7.h
//  My_App
//
//  Created by barney on 15/12/8.
//  Copyright © 2015年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupPurcheaseDetailModel.h"
@interface GroupPurchaseCell7 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *talk;
@property (nonatomic,strong)GroupPurcheaseDetailModel *model;
+(instancetype)cell7WithTableView:(UITableView *)tableView;
@end
