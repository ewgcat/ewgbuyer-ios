//
//  OneYuanClassCell.h
//  My_App
//
//  Created by barney on 16/2/15.
//  Copyright © 2016年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftRightButton.h"
@interface OneYuanClassCell : UITableViewCell
@property (weak, nonatomic) IBOutlet LeftRightButton *firstBtn;
@property (weak, nonatomic) IBOutlet LeftRightButton *secondBtn;
@property (weak, nonatomic) IBOutlet LeftRightButton *thirdBtn;

@end
