//
//  templet_six_Cell.h
//  My_App
//
//  Created by apple on 15/7/23.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface templet_six_Cell : UITableViewCell
@property (strong,nonatomic)UIImageView *imageView_one;
@property (strong,nonatomic)UIImageView *imageView_two;
@property (strong,nonatomic)UIImageView *imageView_three;
@property (strong,nonatomic)UIImageView *imageView_four;

@property (strong,nonatomic)UIImageView *line;
@property (strong,nonatomic)UIImageView *line2;
@property (strong,nonatomic)UIImageView *line3;
@property (strong,nonatomic)UIImageView *line4;

@property (strong,nonatomic)UIButton *OneBtn;
@property (strong,nonatomic)UIButton *TwoBtn;
@property (strong,nonatomic)UIButton *ThreeBtn;
@property (strong,nonatomic)UIButton *FourBtn;

-(void)setData_Left:(NSDictionary *)imageUrlLeft Middle:(NSDictionary *)imageUrlMiddle BottomLeft:(NSDictionary *)bottomUrlLeft BottomRight:(NSDictionary *)bottomUrlRight;
@end
