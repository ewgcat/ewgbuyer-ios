//
//  GroupPurchaseTableViewCell.h
//  
//
//  Created by apple on 15/10/21.
//
//

#import <UIKit/UIKit.h>
#import "GroupModel.h"
@interface GroupPurchaseTableViewCell : UITableViewCell

@property(nonatomic,strong)GroupModel *model;

@end
