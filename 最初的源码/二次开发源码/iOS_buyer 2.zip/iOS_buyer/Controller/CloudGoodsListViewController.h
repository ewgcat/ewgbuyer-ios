//
//  CloudGoodsListViewController.h
//  My_App
//
//  Created by shiyuwudi on 16/2/23.
//  Copyright © 2016年 shiyuwudi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CloudGoodsListViewController : UIViewController
@property (nonatomic,weak)UIButton *latest;
@property (nonatomic,assign)BOOL mark;
@end
