//
//  NotifWebViewController.h
//  My_App
//
//  Created by shiyuwudi on 15/12/21.
//  Copyright © 2015年 shiyuwudi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotifWebViewController : UIViewController

@property (strong, nonatomic)NSURLRequest *request;

@end
