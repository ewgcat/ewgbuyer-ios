//
//  OrderDetailsViewController.h
//  My_App
//
//  Created by apple on 15-2-10.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"

@interface OrderDetailsViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,ASIHTTPRequestDelegate,UIAlertViewDelegate>
{
    UITableView *MyTableView;
    NSMutableArray *dataArray;
    
    ASIFormDataRequest *requestOrderDetails1;
    ASIFormDataRequest *requestOrderDetails2;
    ASIFormDataRequest *requestOrderDetails3;
    ASIFormDataRequest *requestOrderDetails4;
    ASIFormDataRequest *requestOrderDetails12;
    
    UIButton *buttonquxiao;
    NSString *PayStr;
    NSString *canPaytyppe;
}


@property (nonatomic, strong) UILabel *lblGoodsName2;
@property (nonatomic, strong) UILabel *lblGoodsPrice2;
@property (nonatomic, strong) UILabel *lblGoodsNum2;

@end
