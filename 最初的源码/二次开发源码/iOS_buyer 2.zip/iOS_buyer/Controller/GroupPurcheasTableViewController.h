//
//  GroupPurcheasTableViewController.h
//  My_App
//
//  Created by barney on 15/12/8.
//  Copyright © 2015年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GroupPurcheasTableViewController : UITableViewController
@property (nonatomic, copy)NSString *group_id;
@end
