//
//  CloudPurchaseGoodsDetailViewController.h
//  My_App
//
//  Created by barney on 16/2/16.
//  Copyright © 2016年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CloudPurchaseGoodsDetailViewController : UIViewController
@property(nonatomic,copy)NSString *ID;

@end
