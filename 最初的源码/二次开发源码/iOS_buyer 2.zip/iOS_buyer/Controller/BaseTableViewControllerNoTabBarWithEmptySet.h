//
//  BaseTableViewControllerNoTabBarWithEmptySet.h
//  My_App
//
//  Created by shiyuwudi on 16/2/16.
//  Copyright © 2016年 shiyuwudi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTableViewControllerNoTabBarWithEmptySet : UITableViewController

-(void)setRightBtnWithTitle:(NSString *)title normalImg:(NSString *)normalImg highlightImg:(NSString *)highlightImg target:(id)target action:(SEL)action;

@end
