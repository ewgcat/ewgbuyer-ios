//
//  getActivityGoodsViewController.h
//  My_App
//
//  Created by apple on 15/10/20.
//  Copyright © 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface getActivityGoodsViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>{
    

    __weak IBOutlet UICollectionView *MyCollectionView;
    NSMutableArray *topData;
    NSMutableArray *dataArray;
    NSMutableArray *dataArrayUp;
    NSString *pageNum;
    
}





@end
