//
//  AccountSafetyController.h
//  My_App
//
//  Created by barney on 15/11/19.
//  Copyright © 2015年 barney. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccountSafetyController : UIViewController

@end
